﻿using Invoices.Data.Models.Enums;
using Invoices.Data.Models;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace Invoices.DataProcessor.ImportDto;

public class ImportInvoiceDto
{
    [JsonProperty("Number")]
    [Range(1_000_000_000, 1_500_000_000)]
    [Required]
    public int Number { get; set; }

    [JsonProperty("IssueDate")] 
    [Required] 
    public string IssueDate { get; set; } = null!;

    [JsonProperty("DueDate")] 
    [Required] 
    public string DueDate { get; set; } = null!;

    [JsonProperty("Amount")]
    [Required]
    public decimal Amount { get; set; }

    [JsonProperty("CurrencyType")]
    [Range(0, 2)]
    [Required]
    public CurrencyType CurrencyType { get; set; }

    [JsonProperty("ClientId")]
    [Required]
    public int ClientId { get; set; }
}