﻿using Invoices.Data.Models.Enums;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace Invoices.DataProcessor.ImportDto;

public class ImportProductDto
{
    [JsonProperty("Name")]
    [MinLength(9)]
    [MaxLength(30)]
    [Required]
    public string Name { get; set; } = null!;

    [JsonProperty("Price")]
    [Range(5.00, 1000.00)]
    [Required]
    public decimal Price { get; set; }

    [JsonProperty("CategoryType")]
    [Range(0, 4)]
    [Required]
    public CategoryType CategoryType { get; set; }

    [JsonProperty("Clients")] 
    [Required] 
    public int[] ClientIds { get; set; } = null!;
}