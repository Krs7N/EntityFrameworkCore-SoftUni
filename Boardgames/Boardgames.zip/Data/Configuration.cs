﻿namespace Boardgames.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=Boardgames;User Id=sa;Password=SoftUni2023;TrustServerCertificate=True;";
    }
}
